
import 'package:flutter/material.dart';

void main() => runApp(AufstiegsstrategieApp());

class AufstiegsstrategieApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Aufstiegsstrategie',
      home: Scaffold(
        appBar: AppBar(title: Text('Aufstiegsstrategie')),
        body: Center(child: Text('Willkommen zur Aufstiegsstrategie App')),
      ),
    );
  }
}
